xh = input('Enter Hours: ')
xr = input('Enter Rate: ')
xp = float(xh) * float(xr)
print('Pay: ', xp)

# ex