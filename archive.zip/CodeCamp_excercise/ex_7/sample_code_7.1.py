fhand = open('C:\Users\BolengLeng\Documents\GitHub\SpaceHeart\SpaceHeart\CodeCamp_excercise\ex_7\mbox-short.txt')
inp = fhand.read()
print(len(inp))
print(inp[:20])